<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BlogPostController;
use App\Models\BlogPost;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/blog', [BlogPostController::class, 'index']); //แสดงทั้งหมดจาก db
Route::get('/blog/{blogPost}', [BlogPostController::class, 'show']); //แสดง id ของ blog

Route::get('/blog/create/post', [BlogPostController::class, 'create']); //แสดง form create post
Route::post('/blog/create/post', [BlogPostController::class, 'store']); //save post ที่สร้างลง DB

Route::get('/blog/{blogPost}/edit', [BlogPostController::class, 'edit']); //แสดง form edit post
Route::put('/blog/{blogPost}/edit', [BlogPostController::class, 'update']); //save edit post ลง DB
Route::delete('/blog/{blogPost}', [BlogPostController::class, 'destroy']); //ลบ post ใน db

